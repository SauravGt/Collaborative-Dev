<?php

$valveid=$_POST['valveid'];
$valvestatus=$_POST['valvestatus'];
$lastcheck=$_POST['lastcheck'];



$con=mysql_connect("localhost", "root", "");
if(!con)
	(
die('Could not connect:'.mysql_error());
)

mysql_select_db ("demo", $con);

$query= "INSERT INTO valves(VALVE_ID, VALVE_STATUS, LAST_CHECK)
VALUES('$valveid','$valvestatus','$lastcheck')";
if(!mysql_query($query, $con))
	(
die('Error in inserting records'. mysql_error);
) else
	(
echo "Data Inserted";
)
?>

