$( function() {
  var $winHeight = $( window ).height()
  $( '.container' ).height( $winHeight );
});